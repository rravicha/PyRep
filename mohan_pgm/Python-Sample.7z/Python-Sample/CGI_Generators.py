##def my_gen():
##  n = 1
##  print('This is printed first')
##  yield n
##
##  n += 1
##  print('This is printed second')
##  yield n
##
##  n += 1
##  print('This is printed at last')
##  yield n
##
##
##var = my_gen()
##print(next(var))
##
##next(var)
##next(var)


###________________________DefaultDictonary____________

##otherdict=dict((['a',1],['b',2],['c',3]))
##print(otherdict)

###_________________________ List Comprehension in Python________

##var = [x for x in range(10) if x%2==0]
##print(var)
##
##for x in range(10):
##  if x%2 == 0:
##    print(x)
##
#####_________________________Lambda Expression___
##
##double = lambda x : x+2
##print(double(2))
##
##def double(x):
##  print(x+2)
##double(2)
  
