#Sorting Function in dictionary

##mydict = {'carl':40,
##          'alan':2,
##          'bob':1,
##          'danny':3}
##
##for key in sorted(mydict.keys()):
##    print( "%s" % key)

# Note: By default dictionary gonna return unordered output.
