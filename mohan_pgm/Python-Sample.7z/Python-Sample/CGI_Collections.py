import collections
 
# initializing deque
de = collections.deque([1,5,3])
de.append(80)
de.appendleft(90)

print(de)
