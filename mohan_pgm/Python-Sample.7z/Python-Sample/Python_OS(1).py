import os

#------------------------------------------------------------------------

#print(os.getcwd())

#-------------------------------------------------------------------------

#print(os.getcwdb())

#-------------------------------------------------------------------------

#os.chdir(r"c:\Users\sivaraman.m\Desktop\Python-Materials\Python_Documents")
#print(os.getcwd())

#--------------------------------------------------------------------------

#print(os.listdir())

#--------------------------------------------------------------------------

##os.mkdir("india")
##print(os.listdir())

#-------------------------------------------------------------------------

##os.rename("india","pakistan")
##print(os.listdir())

#-------------------------------------------------------------------------------

##os.remove(r"c:\Users\sivaraman.m\Desktop\Python-Materials\Python_Samples\pakistan\poda.txt')
          
##os.rmdir('pakistan')

#--------------------------------------------------------------------------------

##print(os.path.join("c:\\Users\\sivaraman.m", "addedpath"))

#------------------------------------------------------------------------------

##print(os.path.split(r"c:\Users\sivaraman.m\addedpath"))

#-------------------------------------------------------------------------------

##print(os.path.exists(r"C:/Users/Sivaraman.m"))

#------------------------------------------------------------------------------

##print(os.path.isdir(r"C:/Users/Sivaraman.m"))

#--------------------------------------------------------------------------------
##
##for roots,dirs,files in os.walk(r"c:\Users\sivaraman.m\Desktop\Python-Materials\Python_Samples"):
##                #print(roots,len(dirs),len(files))
