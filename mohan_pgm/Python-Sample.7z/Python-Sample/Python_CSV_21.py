import csv

##with open('people.csv', 'r') as csvFile:
##    reader = csv.reader(csvFile)
##    for row in reader:
##        print(row)
##
##csvFile.close()



##csvData = [['Name of Person', 'Age'], ['Peter', '22'], ['Jasmine', '21'], ['Sam', '24']]
##
##with open('person.csv', 'w' , newline = '') as csvFile:
##    writer = csv.writer(csvFile)
##    writer.writerows(csvData)
##
##csvFile.close()




##csvData = [['Peter', '22'], ['Jasmine', '21'], ['Sam', '24']]
##vcsvData = dict(csvData)
##print(vcsvData)
##with open('person.csv', 'w' , newline = '') as csvFile:
##    #fieldnames = ['Peter','Jasmine','Sam']
##    
##    writer = csv.DictWriter(csvFile)
##    writer.writeheader()
##    writer.writerow(vcsvData)
##
##csvFile.close()

##with open('people.csv', 'r') as csvFile:
##    reader = csv.DictReader(csvFile)
##    for row in reader:
##        print(row)
##
##csvFile.close()
