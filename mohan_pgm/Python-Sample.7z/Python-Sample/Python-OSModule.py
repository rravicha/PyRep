import os

##print(os.getcwd)
##print(os.name)
#print(os.getgid())

# --- Unique Cases print(getuid())
# --- print(getpid())


# --- print(os.listdir("c:\"))
