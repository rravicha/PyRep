from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import time
#dirvar = os.get_dir

# create a new Firefox session
driver = webdriver.Chrome("G:\Python_Softwares\chromedriver.exe")
driver.implicitly_wait(30)
driver.maximize_window()
driver.get("https://twitter.com/login")
time.sleep(10)
driver.find_element_by_class_name("js-username-field").send_keys("mohangokulcse@gmail.com")
driver.find_element_by_class_name("js-password-field").send_keys("latinoheat2")
driver.find_element_by_class_name("EdgeButtom--medium").click()
time.sleep(5)
#driver.find_element_by_class_name("js-nav js-tooltip js-dynamic-tooltip").click()
driver.find_element_by_id('tweet-box-home-timeline').send_keys("CGI CGI")
driver.find_element_by_css_selector('button.tweet-action').click()
driver.save_screenshot("i-am-on-twitter.png")
from PIL import Image
img = Image.open("i-am-on-twitter.png")
# absolute filepath is needed
cropped_filename = "G:\Python_Softwares\PythonOutput\cropped-i-am-on-twitter.png"
img.crop((0, 0, img.size[0], 400)).save(cropped_filename)
# Upload the image
driver.find_element_by_css_selector('input.file-input').send_keys(cropped_filename)

time.sleep(10)
