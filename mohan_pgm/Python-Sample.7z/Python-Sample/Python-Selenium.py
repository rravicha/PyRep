from selenium import webdriver
##var = r"C:\Users\Mohan S\Downloads"
##driver = var.chrome()
driver.get("http://google.com");
driver.close()
